module.exports = [
"[project]/.next-internal/server/app/photos/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/src/lib/api.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getUser",
    ()=>getUser,
    "getUsers",
    ()=>getUsers
]);
async function getUsers() {
    const response = await fetch("https://jsonplaceholder.typicode.com/users", {
        next: {
            revalidate: 1800
        }
    });
    if (!response.ok) {
        throw new Error("Failed to fetch users");
    }
    return response.json();
}
async function getUser(id) {
    const response = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`, {
        cache: "no-store"
    });
    if (!response.ok) {
        if (response.status === 404) {
            throw new Error("User not found");
        }
        throw new Error("Failed to fetch user");
    }
    return response.json();
}
}),
"[project]/src/app/photos/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/src/app/photos/page.tsx'");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[project]/src/app/photos/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/photos/page.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ddb19018._.js.map