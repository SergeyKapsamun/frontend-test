module.exports = [
"[project]/.next-internal/server/app/photos/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/console [external] (console, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("console", () => require("console"));

module.exports = mod;
}),
"[project]/src/lib/api.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPhoto",
    ()=>getPhoto,
    "getPhotos",
    ()=>getPhotos
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$console__$5b$external$5d$__$28$console$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/console [external] (console, cjs)");
;
async function getPhotos() {
    const response = await fetch("https://jsonplaceholder.typicode.com/photos", {
        next: {
            revalidate: 1800
        }
    });
    if (!response.ok) {
        throw new Error("Failed to fetch photos");
    }
    const photos = await response.json();
    // Генерация цвета на основе ID фото
    const generateColor = (id)=>{
        const colors = [
            "ef4444",
            "f59e0b",
            "10b981",
            "3b82f6",
            "8b5cf6",
            "ec4899",
            "06b6d4",
            "84cc16",
            "f97316",
            "6366f1"
        ];
        return colors[id % colors.length];
    };
    return photos.map((photo)=>{
        const color = generateColor(photo.id);
        return {
            ...photo,
            url: `https://placehold.co/600x400/${color}/white?text=Photo+${photo.id}`,
            thumbnailUrl: `https://placehold.co/150x150/${color}/white?text=Photo+${photo.id}`
        };
    });
}
async function getPhoto(id) {
    const response = await fetch(`https://placehold.co/${id}`, {
        cache: "no-store"
    });
    if (!response.ok) {
        if (response.status === 404) {
            throw new Error("Photo not found");
        }
        throw new Error("Failed to fetch photo");
    }
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$console__$5b$external$5d$__$28$console$2c$__cjs$29$__["log"])("response", response);
    return response.url;
}
}),
"[project]/src/app/photos/[id]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/src/app/photos/[id]/page.tsx'");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[project]/src/app/photos/[id]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/photos/[id]/page.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__7004546b._.js.map