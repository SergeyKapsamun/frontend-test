__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/9b4b9b490f1e02e3.js",
  "static/chunks/turbopack-8248af5634c7458d.js"
])
