(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_02409dcd._.js",
  "static/chunks/src_app_NotFound_module_412abcb9.css"
],
    source: "dynamic"
});
