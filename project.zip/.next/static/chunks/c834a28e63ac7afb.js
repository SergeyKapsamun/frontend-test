__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/9b4b9b490f1e02e3.js",
  "static/chunks/turbopack-b4b095deb1bc5eee.js"
])
