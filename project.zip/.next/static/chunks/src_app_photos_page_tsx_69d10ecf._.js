(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_c2ad5bda._.js",
  "static/chunks/src_components_PhotoCard_PhotoCard_module_scss_module_f5f60c78.css"
],
    source: "dynamic"
});
