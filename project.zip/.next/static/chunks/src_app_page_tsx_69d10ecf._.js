(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_02409dcd._.js",
  "static/chunks/src_app_page_module_scss_module_b5ea66c3.css"
],
    source: "dynamic"
});
