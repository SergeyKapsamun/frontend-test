__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/b7d3fbdef3b88ca2.js",
  "static/chunks/turbopack-b80de904dcd19e57.js"
])
