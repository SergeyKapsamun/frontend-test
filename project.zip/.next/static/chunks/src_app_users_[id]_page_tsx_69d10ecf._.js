(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_02409dcd._.js",
  "static/chunks/src_app_users_[id]_UserPage_module_scss_module_c37b477d.css"
],
    source: "dynamic"
});
