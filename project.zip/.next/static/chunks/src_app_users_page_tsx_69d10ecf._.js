(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_61de826b._.js",
  "static/chunks/src_9f6817aa._.css"
],
    source: "dynamic"
});
