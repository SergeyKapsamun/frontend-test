__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/b7d3fbdef3b88ca2.js",
  "static/chunks/turbopack-08ce59aaab110c29.js"
])
