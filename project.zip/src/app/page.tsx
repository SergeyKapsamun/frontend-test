import Link from "next/link";
import styles from "./page.module.scss";

export default function Home() {
  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <h1 className={styles.title}>Users Management System</h1>

        <p className={styles.description}>
          Демонстрационное приложение для работы с пользователями через
          JSONPlaceholder API
        </p>

        <div className={styles.buttons}>
          <Link href="/users" className={styles.primaryButton}>
            👥 Смотреть пользователей
          </Link>
        </div>

        <div className={styles.features}>
          <h3 className={styles.featuresTitle}>Технологии:</h3>
          <div className={styles.featuresList}>
            <div className={styles.feature}>Next.js 14 App Router</div>
            <div className={styles.feature}>TypeScript</div>
            <div className={styles.feature}>SCSS модули</div>
            <div className={styles.feature}>SSG/SSR/ISR рендеринг</div>
            <div className={styles.feature}>Адаптивный дизайн</div>
          </div>
        </div>
      </div>
    </div>
  );
}
